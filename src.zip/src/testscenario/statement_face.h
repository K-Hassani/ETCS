/* statement_face.h */
#pragma once

#include <initializer_list>
#include <map>
#include <string>

namespace testscenario {
namespace language {

class statement_face {
private:
  int command_idx_;
  int subcommand_idx_;
  std::map<int, std::string> additional_vars_;
  std::map<int, std::string> subcommand_vars_;

public:
  statement_face(int index_command, int index_subcommand);
  statement_face(
      int index_command, int index_subcommand,
      std::initializer_list<std::pair<int, std::string>> subcommand_variables);
  statement_face(
      int index_command, int index_subcommand,
      std::initializer_list<std::pair<int, std::string>> subcommand_variables,
      std::initializer_list<std::pair<int, std::string>> additional_variables);
};

} // namespace language
} // namespace testscenario