/* action.h */

#pragma once

using action = void (&)();