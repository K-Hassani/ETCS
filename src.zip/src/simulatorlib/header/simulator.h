#pragma once

#include <ch1.h>

namespace simulatorlib {
extern int hello_test();

class simulator {
private:
  ch1 &inbuf_;
  ch1 &outbuf_;

public:
  simulator(ch1 &ch1_, ch1 &ch2_)
      : inbuf_{ch1_}, outbuf_{ch2_} {}
};
} // namespace simulatorlib