/* ch1.h */

#pragma once

#include <string>

namespace simulatorlib {
class ch1 {
public:
  ch1(){};
};
} // namespace simulatorlib