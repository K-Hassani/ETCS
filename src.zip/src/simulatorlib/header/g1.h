/* g1.h */

#pragma once

#include <gateway.h>
#include <string>

namespace simulatorlib {
class g1 {
  
};
} // namespace simulatorlib
