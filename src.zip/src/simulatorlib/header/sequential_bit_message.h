#pragma once
#include <cassert>
#include <cstdint>
#include <vector>

namespace simulatorlib {
class sequential_bit_message {
private:
  uint8_t *buf_;
  int p_;
  std::size_t size_;

public:
  sequential_bit_message(std::size_t size)
      : p_{0}, size_{size}, buf_{new uint8_t[size]} {
    for (std::size_t i = 0; i < size; i++)
      buf_[i] = 0;
  }

  sequential_bit_message(std::vector<uint8_t> v)
      : p_{0}, size_{v.size() * 8}, buf_{new uint8_t[size_]} {
    for (int i = 0; i < size_; i++)
      buf_[i] = v[i];
  }
  ~sequential_bit_message();
  sequential_bit_message(const sequential_bit_message &m);
  sequential_bit_message(sequential_bit_message &&m);
  sequential_bit_message &operator=(const sequential_bit_message &m);
  sequential_bit_message &operator=(sequential_bit_message &&m);

  uint64_t read(int n_bits);
  void seek(std::size_t p) {
    assert(p < size_);
    p_ = p;
  }
};

} // namespace simulatorlib
