#include "bit_message.h"
#include <stdexcept>

namespace simulatorlib {
bit_message::~bit_message() { delete[] arr_; }

bit_message::bit_message(const bit_message &b) {
  if (b.bit_size_ != this->bit_size_)
    throw std::invalid_argument("size of bit messages must be equal");
  for (int i = 0; i < b.bit_size_; i++) {
    arr_[i] = b.arr_[i];
  }
}

bit_message::bit_message(bit_message &&b) {
  if (b.bit_size_ != this->bit_size_)
    throw std::invalid_argument("size of bit messages must be equal");
  arr_ = b.arr_;
  b.arr_ = nullptr;
}

bit_message &bit_message::operator=(const bit_message &b) {
  if (b.bit_size_ != this->bit_size_)
    throw std::invalid_argument("size of bit messages must be equal");
  if (&b != this) {
    for (int i = 0; i < b.bit_size_; i++) {
      arr_[i] = b.arr_[i];
    }
  }
  return *this;
}

bit_message &bit_message::operator=(bit_message &&b) {
  if (b.bit_size_ != this->bit_size_)
    throw std::invalid_argument("size of bit messages must be equal");
  if (&b != this) {
    delete[] arr_;
    arr_ = b.arr_;
    b.arr_ = nullptr;
  }
  return *this;
}

struct bit_rw {
  int byte_index;
  uint8_t *buf;
  uint8_t bit_mask;
  bit_rw(int bit_index_in_message, uint8_t *b)
      : buf{b}, byte_index{bit_index_in_message / 8},
        bit_mask{0x80 >> (bit_index_in_message % 8)} {}

  inline void write_zero() {
    buf[byte_index] &= ~bit_mask;
    next();
  }
  inline void write_one() {
    buf[byte_index] |= bit_mask;
    next();
  }
  inline uint8_t read_bit() {
    uint8_t result = buf[byte_index] & bit_mask;
    next();
    return result;
  }
  inline void next() {
    if (bit_mask == 1) {
      bit_mask = 0x80;
      byte_index++;
    } else
      bit_mask >>= 1;
  }
};

uint64_t bit_message::read_variable(int start, int number_of_bits) const {
  if (start < 0 || number_of_bits < 0 || start + number_of_bits > bit_size_ * 8)
    throw std::out_of_range("read out of range of bit-message");

  uint64_t result = 0;
  bit_rw reader{start, arr_};
  for (int i = 0; i < number_of_bits; i++) {
    result <<= 1;
    if (reader.read_bit() != 0)
      result++;
  }
  return result;
}

void bit_message::write_variable(int start, int number_of_bits,
                                 uint64_t value) {
  if (start < 0 || number_of_bits < 0 || start + number_of_bits > bit_size_ * 8)
    throw std::out_of_range("write out of range of bit-message");

  bit_rw writer{start, arr_};
  uint64_t value_mask = 1 << (number_of_bits - 1);
  for (int i = 0; i < number_of_bits; i++) {
    if ((value_mask & value) == static_cast<uint64_t>(0))
      writer.write_zero();
    else
      writer.write_one();
    value_mask >>= 1;
  }
}
} // namespace simulatorlib