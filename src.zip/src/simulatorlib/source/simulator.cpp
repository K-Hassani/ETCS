#include <simulator.h>

namespace simulatorlib
{
extern int hello_test()
{
    return 110;
}
} // namespace simulatorlib